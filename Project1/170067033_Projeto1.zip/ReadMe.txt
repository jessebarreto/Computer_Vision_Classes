

Para compilar o projeto em um ambiente Unix com o OpenCV basta executar o script buildall.sh.

